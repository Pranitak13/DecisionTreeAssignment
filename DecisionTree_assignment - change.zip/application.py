import pickle
from wsgiref import simple_server
from flask import Flask, request, app
from flask import Response
from flask_cors import CORS
import pandas as pd
from flask import Flask, render_template, request,jsonify
from flask_cors import CORS,cross_origin

application = Flask(__name__)
CORS(application)
application.config['DEBUG'] = True

@application.route('/')  # route to display the home page
@cross_origin()
def homePage():
    return render_template('index.html')


@application.route('/predict',methods=['POST','GET']) # route to show the predictions in a web UI
@cross_origin()
def index():
    if request.method == 'POST':
        try:

            #  reading the inputs given by the user
            Pclass = float(request.form['Pclass'])
            Sex = float(request.form['Sex'])
            Age= float(request.form['Age'])
            SibSp = float(request.form['SibSp'])
            Parch = float(request.form['Parch'])
            Fare = float(request.form['Fare'])



            filename = 'modelForPrediction2.sav'
            loaded_model = pickle.load(open(filename, 'rb')) # loading the model file from the storage

            #loading Scaler pickle file
            scaler = pickle.load(open('standardScalar2.sav', 'rb'))

            # predictions using the loaded model file and scaler file
            prediction = loaded_model.predict(scaler.fit_transform([[Pclass, Sex, Age, SibSp, Parch, Fare]]))
            #prediction = loaded_model.predict(scaler.fit([[Pclass, Sex, Age, SibSp, Parch, Fare]]).transform([[Pclass, Sex, Age, SibSp, Parch, Fare]]))
            #prediction = loaded_model.predict(scaler.transform([[Pclass, Sex, Age, SibSp, Parch, Fare]]))
            print('prediction is', prediction)
            # showing the prediction results in a UI

            if prediction == 1:
                result = ' survived'
            else:
                result = 'Not Survived'

            print('prediction is', result)
            return render_template('results.html', prediction1 = result)
        except Exception as e:
            print('The Exception message is: ', e)
            return 'something is wrong'
       
    else:
        return render_template('index.html')



if __name__ == "__main__":
    #host = '127.0.0.1'
    #port = 8000
    #app.run(host,port,debug=True)
    application.run(host='127.0.0.1', port=8000, debug=True)
    #httpd = simple_server.make_server(host, port, app)
    # print("Serving on %s %d" % (host, port))
    #httpd.serve_forever()